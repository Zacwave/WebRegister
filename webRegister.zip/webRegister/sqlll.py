import mysql.connector
from hasher import hash_am_thinking

def create_database(d_name):
    global cur
    state = "CREATE DATABASE " + d_name
    cur.execute(state)
    pass


def show_database():
    global cur
    cur.execute("SHOW TABLES")
    for x in cur:
        print(x)


def duplicate_check(tn, ty, data):
    value_to_check = data  # Replace with the value you want to check
    table_name = tn  # Replace with your table name
    column_name = ty  # Replace with your column name

    # Write the SQL query to check if the value exists
    query = f"SELECT EXISTS(SELECT 1 FROM {table_name} WHERE {column_name} = %s)"

    # Execute the query
    cur.execute(query, (value_to_check,))

    # Fetch the result
    result = cur.fetchone()

    # Check if the value exists
    if result[0] == 1:
        print(f"Value '{value_to_check}' exists in the table.")
        return 0
    else:
        return 1


def insert_user():
    global cur, db, l
    print("ADMIN DATA")
    us = input("User Name :")
    pas = input("Password: ")
    h_index, pas = hash_am_thinking(pas, 0, True)
    # h_index = str(h_index)
    print('Index :', h_index, 'pas:', pas)
    sql = "INSERT INTO Admin (user_name, password) VALUES (%s, %s)"
    val = (us, pas)
    checker = ("user_name", "password")
    i = 0
    while i < 1:
        j = duplicate_check("Admin",checker[i], val[i])
        i += 1
        if j == 0:
            l = 0
            print("User already exits")
            break
        if j == 1 and i == 1:
            l = 1
            cur.execute(sql, val)
            db.commit()

    print(cur.rowcount, "record inserted.")

    return l


def insert_data(nm, em, nid, cell):
    global cur, db, l
    sql = "INSERT INTO Persons (name, email, national_id, phone_no) VALUES (%s, %s, %s, %s)"
    val = (nm, em, nid, cell)
    checker = ("name", "email", "national_id", "phone_no")
    i = 1
    while i < 4:
        j = duplicate_check("Persons", checker[i], val[i])
        i += 1
        if j == 0:
            l = 0
            break
        if j == 1 and i == 4:
            l = 1
            cur.execute(sql, val)
            db.commit()

    print(cur.rowcount, "record inserted.")

    return l


def table_data(t):
    global cur
    cur.execute("SELECT * FROM " + t)

    result = cur.fetchall()

    for x in result:
        print(x)


def clear_table(t):
    global cur, db
    # SQL query to delete all records from a table (but keep the table structure)
    table_name = t
    sql_query = f"DELETE FROM {table_name}"

    cur.execute(sql_query)

    db.commit()


def delete_row(element):
    global cur, db
    sql_query = f"DELETE FROM Persons WHERE Pname = %s"
    value = element
    cur.execute(sql_query, (value,))
    db.commit()


def close_connection():
    cur.close()
    db.close()



db = mysql.connector.connect(
    host="localhost",
    user="root",
    passwd="Root123!@#",
    database="Register"
)

cur  =db.cursor()

# create_database-----------------------------------------------------------------
# cur.execute("CREATE DATABASE Register")

# alter table---------------------------------------------------------------------
# cur.execute("ALTER TABLE Admin ADD COLUMN salt VARCHAR(32)")

# create table--------------------------------------------------------------------
# cur.execute("CREATE TABLE Persons "
#             "(id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255), "
#             "email VARCHAR(255), "
#             "national_id INT, "
#             "phone_no INT)")
# cur.execute("CREATE TABLE Admin"
#             "(id INT AUTO_INCREMENT PRIMARY KEY, user_name VARCHAR(255), password INT)")

#delete table---------------------------------------------------------------------
# sql = "DROP TABLE Admin"
# cur.execute(sql)

#show database--------------------------------------------------------------------
# show_database()

# insert in table-----------------------------------------------------------------
# insert_data("Peter Parker", "petepark@gmail.com", "539435", "071931345")
# insert_user("Melvin Bark", 12345)

#show data------------------------------------------------------------------------
# table_data("Persons")
# table_data("Admin")

#clear table----------------------------------------------------------------------
# clear_table("Admin")
