from flask import Flask, render_template, request, redirect, url_for, flash
from sqlServer import insert_data, table_data
import pyodbc
from hasher import hash_am_thinking

# Create a Flask instance
app = Flask(__name__)
app.secret_key = 'your_secret_key'

def is_null_or_empty(field):
    return field is None or field.strip() == ""

def get_db():
    db = pyodbc.connect('DRIVER={SQL Server};' +
                        'Server=DESKTOP-BUGKGO7\\SQLEXPRESS;' +
                        'Database=master;' +
                        'Trusted_Connection=True')

    return db

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/start', methods=['GET'])
def start():
    return render_template('Form.html')

@app.route('/register', methods=['GET','POST'])
def register():
    # Collect form data
    name = request.form['name']
    email = request.form['email']
    id_number = request.form['id_number']
    phone_number = request.form['phone_number']

    if is_null_or_empty(name) or is_null_or_empty(email) or is_null_or_empty(id_number) or is_null_or_empty(
            phone_number):
        flash('All fields are required. Please fill in all fields.', 'error')
        return redirect(url_for('start'))
    if len(phone_number) != 10:
        flash('enter appropriate phone number.', 'error')
        return redirect(url_for('start'))

    l = insert_data(name, email, id_number, phone_number)
    table_data("Persons")
    print(l, type(l))

    if l == 0:
        print("fail")
        flash('Registration failed, please try again.', 'error')
        return redirect(url_for('start'))
    if l == 1:
        print("success")
        flash('Registration successful!', 'success')
        return redirect(url_for('start'))


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        db = get_db()
        cursor = db.cursor()

        # Query to check if the username exists
        cursor.execute('SELECT * FROM Admin WHERE username = ?', (username,))
        user = cursor.fetchone()
        print(user.username, user.pasw, user.hash_index)

        if user:
            x = user.pasw
            print(x)
            y = user.hash_index
            x = hash_am_thinking(x, y, False)
            print(x)
            if x == password:
                print("Yes")
                flash('Login successful!', 'success')
                cursor.close()
                db.close()
                return redirect(url_for('table'))

            if x != password:
                print("no")
                flash('Invalid password. Please try again.', 'error')
        else:
            print("no")
            flash('Username not found. Please check your input.', 'error')

    return render_template('login.html')

@app.route('/table', methods=['GET'])
def table():
    # Connect to the database
    db = get_db()
    cursor = db.cursor()

    # Query to fetch data
    cursor.execute("SELECT * FROM Persons")
    data = cursor.fetchall()  # Fetch all rows

    # Close the connection
    cursor.close()
    db.close()

    # Pass the data to the template
    return render_template('tableView.html', data=data)

@app.route('/home')
def home():
    return render_template('home.html')


@app.after_request
def add_no_cache_headers(response):
    response.cache_control.no_store = True
    return response

# Start the Flask server
if __name__ == '__main__':
    app.run(debug=True)
