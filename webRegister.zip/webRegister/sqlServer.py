import pyodbc
from hasher import hash_am_thinking

def create_database(d_name):
    global cur
    state = "CREATE DATABASE " + d_name
    cur.execute(state)
    pass


def show_database():
    global cur
    cur.execute("SHOW TABLES")
    for x in cur:
        print(x)


def duplicate_check(tn, ty, data):
    value_to_check = data  # Replace with the value you want to check
    table_name = tn  # Replace with your table name
    column_name = ty  # Replace with your column name

    # Write the SQL query to check if the value exists
    query = f"SELECT COUNT(1) FROM {table_name} WHERE {column_name} = ?"

    # Execute the query
    cur.execute(query, (value_to_check,))

    # Fetch the result
    result = cur.fetchone()

    # Check if the value exists
    if result[0] == 1:
        print(f"Value '{value_to_check}' exists in the table.")
        return 0
    else:
        return 1


def insert_user():
    global cur, db, l
    print("ADMIN DATA")
    us = input("User Name :")
    pas = input("Password: ")
    h_index, pas = hash_am_thinking(pas, 0,True)
    # h_index = str(h_index)
    print('Index :', h_index, 'pas:', pas)
    sql = "INSERT INTO Admin (username, pasw, hash_index) VALUES (?, ?, ?)"
    val = (us, pas, h_index)
    i = 0
    while i < 1:
        j = duplicate_check("Admin","username", us)
        i += 1
        if j == 0:
            l = 0
            print("User already exits")
            break
        if j == 1 and i == 1:
            l = 1
            print('yes')
            cur.execute(sql, val)
            db.commit()

    print(cur.rowcount, "record inserted.")

    return l


def insert_data(nm, em, nid, cell):
    global cur, db, l
    sql = "INSERT INTO Persons (Pname, email, national_id, phone_no) VALUES (?, ?, ?, ?)"
    val = (nm, em, nid, cell)
    checker = ("Pname", "email", "national_id", "phone_no")
    i = 1
    while i < 4:
        j = duplicate_check("Persons", checker[i], val[i])
        i += 1
        if j == 0:
            l = 0
            break
        if j == 1 and i == 4:
            l = 1
            cur.execute(sql, val)
            db.commit()
            # cur.close()
            # db.close()

    print(cur.rowcount, "record inserted.")

    return l


def table_data(t):
    global cur
    cur.execute(f"SELECT * FROM {t}")

    result = cur.fetchall()

    for x in result:
        print(x)


def clear_table(t):
    global cur, db
    # SQL query to delete all records from a table (but keep the table structure)
    table_name = t
    sql_query = f"DELETE FROM {table_name}"

    cur.execute(sql_query)

    db.commit()


def delete_row(element):
    global cur, db
    sql_query = f"DELETE FROM Persons WHERE Pname = ?"
    value = element
    cur.execute(sql_query, (value,))
    db.commit()


def close_connection():
    cur.close()
    db.close()


try:
    # Establish the connection
    db = pyodbc.connect('DRIVER={SQL Server};'+
                          'Server=DESKTOP-BUGKGO7\\SQLEXPRESS;'+
                          'Database=master;'+
                          'Trusted_Connection=True')

    # Create a cursor from the connection
    cur = db.cursor()
    # delete_row("Tony Stark")
    # insert_user()
    # table_data("Admin")
    # cur.close()
    # db.close()

    # conn.close()
except pyodbc.Error as ex:
    print("Error :", ex)

# Don't forget to close the connection
# conn.close()