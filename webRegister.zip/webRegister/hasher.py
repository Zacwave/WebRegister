import random


def hash_switching(orignal_list, list_changer, pas):
    i = 0
    pas2 = ""
    ln = len(pas)
    print("Password Length :", ln)

    while i < ln:
        j = pas[i]
        k = orignal_list.index(j)
        l = list_changer[k]
        pas2 = f"{pas2} {l}"
        i += 1
    return pas2


def hash_am_thinking(pas, hash_index, to_hash):
    global lt, lt1
    if to_hash:
        l = random.choice(lt)
        hash_index = lt.index(l)
        new_pass = hash_switching(lt1, l, pas)
        new_pass = new_pass.replace(" ","")
        return hash_index, new_pass
    if not to_hash:
        l = lt[hash_index]
        print(l)
        original_pas = hash_switching(l, lt1, pas)
        original_pas = original_pas.replace(" ", "")
        return original_pas


def hash_tester():
    print("Choose 1.Password to hash 2.Hash to password")
    p = input()
    if p == '1':
        ps = input("Password :")
        h_index, h_pass = hash_am_thinking(ps, 0, True)
        print("Hash index :", h_index)
        print("Hashed Password :", h_pass)
    if p == '2':
        ps = input("Hashed Password :")
        h_index = int(input("Hash index :"))
        pss = hash_am_thinking(ps, h_index,False)
        print("Original Password :", pss)


def list_creator(refList):
    i = 0
    newList = []
    ln = len(refList)
    while i < ln:
        print(refList[i])
        k = 0
        while k == 0:
            j = random.choice(refList)
            print(j)
            if j not in newList:
                newList.append(j)
                print("succes")
                k = 1
            else:
                k = 0
        i += 1

    print(newList)


lt1 = ['q','w','e','r','t','y','u','i','o','p','[',']','a','s','d','f',
       'g','h','j','k','l',';',"'",'"','z','x','c','v','b','n','m',',',
      '.','/','Q','W','E','R','T','Y','U','I','O','P','{','}','A','S','D',
       'F','G','H','J','K','L',':','Z','X','C','V','B','N','M','<','>','?','1','2',
       '3','4','5','6','7','8','9','0','!','@','#','$','%','^','&','*','(',')',
       '-','=','_','+']

lt2 = ['H', '#', 'W', '"', '0', 'N', '7', 'I', 'l', '6', 'S', '{', 'z', 'b', '&',
       '4', 'k', 'B', 'd', '}', '(', 'K', '@', 'L', 'J', 'E', '3', '$', '*', '8',
       '=', '%', '?', 'V', 'U', "'", ',', 'a', 'f', '_', '/', 'w', 'q', '1', '-',
       '+', ')', '.', 'm', 'C', '<', 'o', 'F', ']', '^', 'X', 's', 'Q', '2', 'c',
       'h', ':', 'j', 'P', 'u', 'D', 'r', '5', 'y', 'A', 't', '9', '[', 'M', '!',
       '>', 'e', ';', 'Y', 'G', 'i', 'O', 'p', 'g', 'x', 'Z', 'T', 'R', 'n', 'v']

lt3 = ['a', 'q', 'g', '{', 'z', ',', 'f', 'w', 'K', '@', 'o', 'l', '-', 'H', ':',
       'L', '5', ')', 'v', '1', 'i', 'm', 'Y', 's', "'", 't', 'X', 'b', '6', '_',
       '9', 'V', 'W', 'J', 'O', '2', 'x', '"', 'A', '&', '%', '4', '#', 'k', 'e',
       'U', 'p', '[', '$', '}', '*', 'r', 'R', 'h', '7', '0', 'c', 'F', 'B', 'M',
       '^', '?', '=', 'n', 'j', 'T', 'd', '3', 'N', ';', '.', '/', 'y', 'Q', 'C',
       'I', '(', 'D', '+', '8', '<', ']', 'P', 'u', '>', 'S', 'E', 'Z', '!', 'G']

lt4 = ['*', 'y', '4', 'b', 'q', 'k', '}', '/', '^', 'R', 'o', 'F', '3', 'Q', 'O',
       'B', '&', 'i', '[', 'j', ',', ')', '$', 'r', '@', 'S', ':', 'Z', 'G', 'H',
       'X', '0', 'Y', 'v', ';', 'p', 'l', '8', 'a', 'h', '1', 'N', 'I', 'c', '"',
       '%', '=', '.', '(', '#', 'W', 'J', '!', 't', '6', '9', 'L', 'C', '5', '2',
       'n', 'd', 'g', 'u', '<', '{', ']', '>', 'E', 'D', 'V', 'P', 'K', 'e', '_',
       '?', 'T', 'x', '-', 'A', 'm', "'", 'f', '+', 'U', 'w', 'M', 's', '7', 'z']

lt5 = ['W', 'x', '2', 's', 'a', 'o', '!', '4', 'E', '-', ']', 'G', 'f', '}', 'w',
       '$', '_', '>', 'g', '^', '<', "'", 'y', 'F', 'P', 'D', '&', '=', 'R', '7',
       'm', 'u', '?', '"', 'j', 'B', 'Y', 'z', 'H', 'q', 'd', ';', 'A', 'v', 'Z',
       'r', 'I', 'V', '0', 'J', 'b', ')', ':', 'i', 'U', 'S', 'Q', '.', 'L', 'h',
       'n', 'k', '1', 'e', '/', '{', 'C', '8', '9', '(', 'K', '+', 'p', '[', '%',
       '*', '@', 'X', 'M', '6', 'l', 't', ',', 'N', 'T', '3', '5', '#', 'O', 'c']



lt = [lt2, lt3, lt4, lt5]


# hash_tester()
# list_creator(lt1)
